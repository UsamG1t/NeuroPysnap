"""Terminal emulation utilities built on top of :mod:`pyte`."""

from __future__ import annotations

import re
import unicodedata

import pyte
# ``pyte`` decides what to draw with this cached ``wcwidth``; reusing it keeps
# the rule below identical to the one inside ``Screen.draw``.
from pyte.screens import HistoryScreen, wcwidth

_HEX_COLOR_RE = re.compile(r"^[0-9a-fA-F]{3}([0-9a-fA-F]{3})?$")
_ANSI_BRIGHT_COLOR_ALIASES = {
    "brightblack": "ansibrightblack",
    "brightred": "ansibrightred",
    "brightgreen": "ansibrightgreen",
    "brightbrown": "ansibrightyellow",
    "brightyellow": "ansibrightyellow",
    "brightblue": "ansibrightblue",
    "brightmagenta": "ansibrightmagenta",
    "brightcyan": "ansibrightcyan",
    "brightwhite": "ansiwhite",
    "bfightmagenta": "ansibrightmagenta",
}


class _InvisibleSafeHistoryScreen(HistoryScreen):
    """History screen that does not lose text after invisible characters.

    ``pyte`` stops drawing the rest of a chunk at the first character without
    width that is not a combining mark, for example U+200B or U+202E. Such
    characters are replaced before drawing: dropped by default, or shown as a
    visible placeholder.
    """

    def __init__(self, *args: object, invisible_replacement: str = "", **kwargs: object) -> None:
        """Initialize the screen.

        :param invisible_replacement: Text drawn instead of an invisible
            character; empty to skip it.
        """
        super().__init__(*args, **kwargs)
        self._invisible_replacement = invisible_replacement

    def draw(self, data: str) -> None:
        """Draw text after replacing characters ``pyte`` would stop at."""
        super().draw(
            "".join(
                self._invisible_replacement if is_invisible_character(char) else char
                for char in data
            )
        )


def is_invisible_character(char: str) -> bool:
    """Return whether ``pyte`` would stop drawing at this character.

    :param char: One character.
    :returns: ``True`` for characters without width that do not combine
        with the previous character.
    """
    width = wcwidth(char)
    return width < 0 or (width == 0 and not unicodedata.combining(char))


class TerminalEmulator:
    """Wrap a :class:`pyte.Screen` and render it for the TUI."""

    def __init__(
        self,
        columns: int = 80,
        lines: int = 24,
        history: int = 5000,
        invisible_replacement: str = "",
    ) -> None:
        """Initialize the terminal emulator.

        :param columns: Initial terminal width.
        :param lines: Initial terminal height.
        :param history: Number of scrollback lines to keep locally.
        :param invisible_replacement: Text drawn instead of invisible
            characters such as U+200B; empty to skip them like a terminal.
        """
        self.screen = _InvisibleSafeHistoryScreen(
            columns,
            lines,
            history=history,
            invisible_replacement=invisible_replacement,
        )
        self.stream = pyte.ByteStream(self.screen)
        self._style_cache: dict[tuple, str] = {}

    def feed(self, data: bytes) -> None:
        """Feed new bytes into the terminal parser.

        Parsing while the local viewport is scrolled back would write into
        the manually rotated history buffers and lose lines, so the view
        first returns to the live bottom. This mirrors the common
        jump-to-bottom-on-output behavior of desktop terminals.

        :param data: Raw bytes read from the VM serial socket.
        """
        if self.is_scrollback_active:
            self.scroll_to_bottom()
        self.stream.feed(data)

    def resize(self, columns: int, lines: int) -> None:
        """Resize the virtual screen.

        :param columns: New terminal width.
        :param lines: New terminal height.
        """
        if columns < 1 or lines < 1:
            return
        if self.screen.columns == columns and self.screen.lines == lines:
            return
        self.screen.resize(lines=lines, columns=columns)

    def scroll_up(self, lines: int = 1) -> None:
        """Scroll the local view toward older history lines.

        :param lines: Number of lines to move upward.
        """
        self._scroll_history_up(max(lines, 1))

    def scroll_down(self, lines: int = 1) -> None:
        """Scroll the local view toward newer history lines.

        :param lines: Number of lines to move downward.
        """
        self._scroll_history_down(max(lines, 1))

    def scroll_to_top(self) -> None:
        """Jump to the oldest locally retained history."""
        while self._scroll_history_up(self.screen.lines):
            continue

    def scroll_to_bottom(self) -> None:
        """Jump back to the live end of the terminal output."""
        while self._scroll_history_down(self.screen.lines):
            continue

    @property
    def is_scrollback_active(self) -> bool:
        """Return whether the current view is above the live output bottom."""
        return self.screen.history.position < self.screen.history.size

    def as_formatted_text(
        self,
        selection: tuple[tuple[int, int], tuple[int, int]] | None = None,
    ) -> list[tuple[str, str]]:
        """Render the current screen buffer as prompt_toolkit fragments.

        :param selection: Optional inclusive start/end cell coordinates.
        :returns: A list of ``(style, text)`` fragments.
        """
        fragments: list[tuple[str, str]] = []
        cursor = self.screen.cursor
        for y in range(self.screen.lines):
            line = self.screen.buffer[y]
            run_style = ""
            run_characters: list[str] = []
            for x in range(self.screen.columns):
                char = line[x]
                style = self._cell_style(char)
                if selection and _cell_in_selection(y=y, x=x, selection=selection):
                    style = f"{style} reverse".strip()
                if not cursor.hidden and cursor.x == x and cursor.y == y:
                    style = f"{style} reverse".strip()
                if style != run_style and run_characters:
                    fragments.append((run_style, "".join(run_characters)))
                    run_characters = []
                run_style = style
                run_characters.append(char.data)
            if run_characters:
                fragments.append((run_style, "".join(run_characters)))
            if y != self.screen.lines - 1:
                fragments.append(("", "\n"))
        return fragments

    def selected_text(
        self,
        selection: tuple[tuple[int, int], tuple[int, int]] | None,
    ) -> str:
        """Return the textual content inside a visible selection range.

        :param selection: Inclusive start/end cell coordinates.
        :returns: Selected text with newline joins between screen rows.
        """
        if selection is None:
            return ""

        (start_row, start_col), (end_row, end_col) = selection
        selected_lines: list[str] = []

        for row in range(start_row, end_row + 1):
            left = start_col if row == start_row else 0
            right = end_col if row == end_row else self.screen.columns - 1
            line = self.screen.buffer[row]
            selected_lines.append(
                "".join(line[column].data for column in range(left, right + 1)).rstrip()
            )

        return "\n".join(selected_lines).rstrip("\n")

    def _scroll_history_up(self, lines: int) -> bool:
        """Move the local viewport upward through retained history.

        :param lines: Maximum number of lines to move.
        :returns: ``True`` when the viewport changed.
        """
        history = self.screen.history
        if history.position <= self.screen.lines or not history.top:
            return False

        amount = min(len(history.top), max(lines, 1), history.position - self.screen.lines)
        history.bottom.extendleft(
            self.screen.buffer[y]
            for y in range(self.screen.lines - 1, self.screen.lines - amount - 1, -1)
        )
        self.screen.history = history._replace(position=history.position - amount)

        for y in range(self.screen.lines - 1, amount - 1, -1):
            self.screen.buffer[y] = self.screen.buffer[y - amount]
        for y in range(amount - 1, -1, -1):
            self.screen.buffer[y] = self.screen.history.top.pop()

        self.screen.dirty = set(range(self.screen.lines))
        self.screen.after_event("prev_page")
        return True

    def _scroll_history_down(self, lines: int) -> bool:
        """Move the local viewport downward toward live output.

        :param lines: Maximum number of lines to move.
        :returns: ``True`` when the viewport changed.
        """
        history = self.screen.history
        if history.position >= history.size or not history.bottom:
            return False

        amount = min(len(history.bottom), max(lines, 1), history.size - history.position)
        history.top.extend(self.screen.buffer[y] for y in range(amount))
        self.screen.history = history._replace(position=history.position + amount)

        for y in range(self.screen.lines - amount):
            self.screen.buffer[y] = self.screen.buffer[y + amount]
        for y in range(self.screen.lines - amount, self.screen.lines):
            self.screen.buffer[y] = self.screen.history.bottom.popleft()

        self.screen.dirty = set(range(self.screen.lines))
        self.screen.after_event("next_page")
        return True

    def _cell_style(self, char: pyte.screens.Char) -> str:
        """Return the cached prompt-toolkit style string for one cell.

        Screens repeat a small number of distinct styles across thousands of
        cells, so caching the joined style string keeps rendering cheap.

        :param char: Character cell from the virtual screen.
        :returns: Prompt-toolkit style string.
        """
        key = (
            char.fg,
            char.bg,
            char.bold,
            char.italics,
            char.underscore,
            char.strikethrough,
            char.reverse,
        )
        cached = self._style_cache.get(key)
        if cached is None:
            cached = " ".join(self._style_parts(char))
            self._style_cache[key] = cached
        return cached

    def _style_parts(self, char: pyte.screens.Char) -> list[str]:
        """Translate a ``pyte`` character style into prompt_toolkit styles.

        :param char: Character cell from the virtual screen.
        :returns: Prompt-toolkit style tokens.
        """
        style_parts: list[str] = []
        foreground = _normalize_style_color(char.fg)
        background = _normalize_style_color(char.bg)
        if foreground:
            style_parts.append(f"fg:{foreground}")
        if background:
            style_parts.append(f"bg:{background}")
        if char.bold:
            style_parts.append("bold")
        if char.italics:
            style_parts.append("italic")
        if char.underscore:
            style_parts.append("underline")
        if char.strikethrough:
            style_parts.append("strike")
        if char.reverse:
            style_parts.append("reverse")
        return style_parts


def _normalize_style_color(color: str) -> str | None:
    """Normalize one ``pyte`` color value for prompt-toolkit.

    ``pyte`` may expose colors as plain hex strings like ``8a8a8a`` or as
    bright ANSI names such as ``brightred``. Prompt-toolkit expects hex colors
    with a leading ``#`` and uses ``ansibright*`` names for bright ANSI tones.

    :param color: Raw color string from ``pyte``.
    :returns: A prompt-toolkit compatible color token or ``None`` for default.
    """
    if color in {"", "default"}:
        return None

    lowered = color.lower()
    if lowered in _ANSI_BRIGHT_COLOR_ALIASES:
        return _ANSI_BRIGHT_COLOR_ALIASES[lowered]
    if color.startswith("#") and _HEX_COLOR_RE.fullmatch(color[1:]):
        return color
    if _HEX_COLOR_RE.fullmatch(color):
        return f"#{color}"
    return color


def _cell_in_selection(
    *,
    y: int,
    x: int,
    selection: tuple[tuple[int, int], tuple[int, int]],
) -> bool:
    """Return whether one visible cell belongs to the active selection."""
    (start_row, start_col), (end_row, end_col) = selection
    if y < start_row or y > end_row:
        return False
    if start_row == end_row:
        return y == start_row and start_col <= x <= end_col
    if y == start_row:
        return x >= start_col
    if y == end_row:
        return x <= end_col
    return True
