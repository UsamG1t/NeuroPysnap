"""Configuration helpers for PySnap."""
