"""Runtime helpers for PySnap."""
