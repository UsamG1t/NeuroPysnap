"""PySnap package."""

__all__ = ["__version__"]

__version__ = "2.2.2"
